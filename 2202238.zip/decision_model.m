% This is prediction model for the first 60 days
ex_rate = [1, 0.99, 0.98]; % cash, gold, bitcoin
short_term_gap = 10;
long_term_gap = 60;
B_St = table2array(bitcoin101(:, 1));
B_E_St = table2array(bitcoin101(:, 2));
B_sigma2 = table2array(bitcoin101(:, 7));
B_R = table2array(bitcoin101(:, 6));
G_St = table2array(gold101(:, 1));
G_E_St = table2array(gold101(:, 2));
G_sigma2 = table2array(gold101(:, 7));
G_R = table2array(gold101(:, 6));
len = length(B_St); % 1811
begin_days = 60;
% Handle first 60 days
ptn_60 = [500, 0, 500, 0]; % gold_cash, gold, bitcoin_cash, bitcoin
data_list = []
for day = 1 : begin_days
    if day == 1
        ptn_60(2) = (ptn_60(1) / G_St(day)) * ex_rate(1) * ex_rate(2);
        ptn_60(1) = 0;
        ptn_60(4) = (ptn_60(3) / B_St(day)) * ex_rate(1) * ex_rate(3);
        ptn_60(3) = 0;
    else
        % Handle gold
        G_prev = -1;
        if mod(day - 1, 7) == 5 || mod(day - 1, 7) == 6 % Weekends not Work
            G_prev = -1;
        elseif mod(day - 1, 7) == 0 % Today is Monday, so use last Friday's
            G_prev = day - 3;
        else
            G_prev = day - 1;
        end
        if G_prev ~= -1
            if G_R(G_prev) > 0 && G_St(G_prev) > G_E_St(G_prev) ...
                    && ptn_60(1) > 0 % case 1: all in
                ptn_60(2) = ptn_60(2) + (ptn_60(1) / G_St(G_prev)) ...
                    * ex_rate(1) * ex_rate(2);
                ptn_60(1) = 0;
            elseif G_R(G_prev) < 0 && G_St(G_prev) < G_E_St(G_prev) ...
                    && ptn_60(2) > 0 % case 4: all out
                ptn_60(1) = ptn_60(1) + (ptn_60(2) * G_St(G_prev)) ...
                    * ex_rate(1) * ex_rate(2);
                ptn_60(2) = 0;
            end
        end
        % Handle bitcoin
        B_prev = day - 1;
        if B_R(B_prev) > 0 && B_St(B_prev) > B_E_St(B_prev) ...
                && ptn_60(1) > 0 % case 1: all in
            ptn_60(4) = ptn_60(4) + (ptn_60(3) / B_St(B_prev)) ...
                * ex_rate(1) * ex_rate(3);
            ptn_60(3) = 0;
        elseif B_R(B_prev) < 0 && B_St(B_prev) < B_E_St(B_prev) ...
                && ptn_60(3) > 0 % case 4: all out
            ptn_60(3) = ptn_60(3) + (ptn_60(4) * B_St(B_prev)) ...
                * ex_rate(1) * ex_rate(3);
            ptn_60(4) = 0;
        end
    end
    tot = ptn_60(1) + ptn_60(3) + ptn_60(2) * G_St(day) + ptn_60(4) * B_St(day);
    data_list(end + 1, :) = [ptn_60(4), ptn_60(3), ptn_60(2), ptn_60(1), tot];
end

%This is the function for the indepent market analysis
function [newB,newCB,trade_information,trade_node, daily_store_bit]=...
    bitcoin_operation(startday, endday, S_t_true,  B, CB)
% Input:
% startday: starting time of the program  an integer between 1 and 1811
% endday: end time of the program         an integer between 1 and 1811
% category: 0 represent bitcoin, 1 represent gold
% bitcoin_S_t_actual 1811 * 1 double
exchange_rate = [1, 0.99, 0.98];
short_term_gap = 10;
long_term_gap = 60;
daily_store_bit=[];
sub_store=[];
bitcoin_S_t_actual = S_t_true;
len = length(bitcoin_S_t_actual); % 1811
trade_information = [];
trade_node = [];
threshold_pos = 0.3;
threshold_neg = 0.03;
portion = [CB, 0, B];  % cash, gold, bitcoin
trade_point = 0;
for i = startday: endday-1
    short_term_average(i) = sum(bitcoin_S_t_actual(i-9:i))/10;
    long_term_average(i) = sum(bitcoin_S_t_actual(i-59:i))/60;
    delta(i) = short_term_average(i) - long_term_average(i);
    k = (short_term_average(i) - long_term_average(i))...
        / short_term_average(i); %bitcoin_S_t_actual(i - 1);
    flag = 0;
    if k > threshold_pos && delta(i) < delta(i - 1)
        if portion(3) > 0
            trade_point = trade_point + 1;
            trade_node(end+1)=i;
            flag=2;
            trade_information(end+1)=portion(3);
        end
        portion(1) = portion(1) + portion(3) * exchange_rate(3)...
            * exchange_rate(1) * bitcoin_S_t_actual(i - 1);
        portion(3) = 0;
    elseif k < -threshold_neg && delta(i) > delta(i - 1)
        if portion(1) > 0
            trade_point = trade_point + 1;
            trade_node(end+1)=i;
            trade_information(end+1)=portion(1);
            flag=1;
        end
        portion(3) = portion(3) + portion(1) * exchange_rate(1)...
            * exchange_rate(3) / bitcoin_S_t_actual(i - 1);
        portion(1) = 0;
    end
    sub_store = [sub_store portion(3)];
    sub_store = [sub_store portion(1)];
    sub_store = [sub_store flag];
    daily_store_bit = [daily_store_bit;sub_store];
    sub_store = [];
end
cash = 1 * portion(1) + bitcoin_S_t_actual(i) * portion(3);
newCB = portion(1);
newB = portion(3);

%main function using the cross-market model
for i= startday : endday
    if mod(i,28)==5
        R_G_month = (gold_true(i) - gold_true(i-28)) / gold_true(i-28);
        R_B_month = (bitcoin_true(i) - bitcoin_true(i-28)) / bitcoin_true(i-28);
        R_G_total = (gold_true(i) - gold_true(1)) / gold_true(1);
        R_B_total = (bitcoin_true(i) - bitcoin_true(1)) / bitcoin_true(1);
        if R_G_month > R_B_month
            CG=CB+CG;
            CB = 0;
        else
            CB=CG+CB;
            CG = 0;
        end
        if R_G_month > R_B_month + alpha_B
            k = R_G_total / (R_G_total + R_B_total);
            if k<0
                k=0;
            elseif k>1
                k=1;
            end
            CG = CG + B * bitcoin_true(i) * (1 - alpha_B) * k;
            B = B * (1 - k);
        elseif R_B_month > R_G_month + alpha_G
            k = R_B_total / (R_G_total + R_B_total);
            if k<0
                k=0;
            elseif k>1
                k=1;
            end
            CB = CB + G * gold_true(i) * (1 - alpha_G) * k;
            G = G * (1 - k);
        end
    end
    if mod(i,28)==5 && i == 61
        [B,CB,a,b,bit_restore] = bitcoin_operation(i, i + 28,...
        bitcoin_true(1 : i + 28),  B, CB);
        bit_info = [bit_info;bit_restore] ;
    elseif mod(i,28)==5
            [B,CB,a,b,bit_restore] = bitcoin_operation(i, i + 28,...
            bitcoin_true(1 : i + 28),  B, CB);
            bit_info = [bit_info;bit_restore] ;
            [G,CG,a,b,gold_restore] = gold_operation(floor(i/28)*20 +5,...
            floor(i/28)*20 + 25,gold_true_nonzero(1 : floor(i/28)*20 + 25)...
            ,  G, CG);
            gold_info = [gold_info;gold_restore] ;
    end
end
