import math
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.linear_model import LogisticRegression
from sklearn import linear_model
'''
whether gold or bitcoin: 1 for gold, 2 for bitcoin
'''
ch = 2
G_or_B = gold_data['USD (PM)']
G_or_B_date = gold_data['date']
G_or_B_Date = gold_data['Date']
filename = ''
if ch == 1: 
    G_or_B = gold_data['USD (PM)']
    G_or_B_date = gold_data['date']
    G_or_B_Date = gold_data['Date']
    filename = 'gold'
elif ch == 2: 
    G_or_B = bitcoin_data['Value']
    G_or_B_date = bitcoin_data['date']
    G_or_B_Date = bitcoin_data['Date']
    filename = 'bitcoin'
step_interval = 10 # window size
G_or_B_len = len(G_or_B) # length of bitcoin_data
G_or_B_E_St = [] # prediction
G_or_B_sigma2 = [] # sigma ^ 2: variance of ln_St
G_or_B_mu = [] # mu: exchange_rate of return
next_interval = 1 # how many days to predict 
next_E_St = [] # prediction values from current day to 'next_interval' days later
next_St_va = []
R_list = []
B_t = 0.0
filename = '-'.join([filename, str(step_interval), str(next_interval)]) + '.csv'
for day in range(0, step_interval):
    G_or_B_E_St.append(G_or_B[day])
for day in range(step_interval, G_or_B_len):
    X, y = [[0]], [0]
    start_day = day - step_interval
    ln_S0 = math.log(G_or_B[start_day])
    for end_day in range(start_day + 1, day):
        ln_St = math.log(G_or_B[end_day])
        t = end_day - start_day
        # compute sigma * sigma using formula
        sigma2 = 0
        for i in range(start_day, end_day):
            sigma2 = sigma2 + math.pow(math.log(G_or_B[i + 1] / G_or_B[i]), 2)
        sigma2 = sigma2 / t

        X.append([t])
        y.append(ln_St - ln_S0 + 0.5 * sigma2 * t - B_t * math.sqrt(sigma2))
    '''
    linear regression
    '''
    clf = linear_model.LinearRegression()
    clf.fit(X, y)
    # compute sigma * sigma using formula
    t = day - start_day
    sigma2 = 0
    for i in range(start_day, day):
        sigma2 = sigma2 + math.pow(math.log(G_or_B[i + 1] / G_or_B[i]), 2)
    sigma2 = sigma2 / t
    G_or_B_sigma2.append(sigma2)
    # mu
    mu = clf.coef_[0]
    G_or_B_mu.append(mu)
    # R
    R = math.exp(mu) - 1
    R_list.append(R)
    # next_St_mean
    next_St_mean = G_or_B[day - 1] * np.vectorize(math.exp)(mu * \
                    np.linspace(1, next_interval, num=next_interval))
    next_E_St.append(next_St_mean.tolist())
    G_or_B_E_St.append(next_St_mean[0])
    # next_St_va
    next_St_va = [math.pow(G_or_B[day - 1], 2) * math.exp(2 * mu) \
                    * (math.exp(sigma2) - 1)]
    for i in range(day + 1, day + next_interval):
        next_St_va.append(math.pow(next_St_va[i - day - 1], 2) \
        * math.exp(2 * mu) * (math.exp(sigma2) - 1))
    next_St_va.append(next_St_va[0])
X = np.linspace(0, G_or_B_len - 1, num=G_or_B_len).tolist()
y = G_or_B.tolist()
y_pred = G_or_B_E_St
plt.plot(X, y, 'r-', X, y_pred, 'b-')